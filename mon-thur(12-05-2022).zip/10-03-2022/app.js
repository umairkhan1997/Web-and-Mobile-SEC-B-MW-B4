// var res = prompt('Where is karachi');

// if(res == "Pakistan"){
//     alert('correct!')
// }
// else{
//     alert('Incorrect!')
// }


// var res = prompt('Name some cities of pakistan');

// if(res == "karachi"){
//     alert('correct!')
// }
// else if(res == "Peshawar"){
//     alert('correct!')
// }
// else if(res == "Quetta"){
//     alert('correct!')
// }
// else if(res == "Islamabad"){
//     alert('correct!')
// }
// else{
//     alert('Incorrect!')
// }



// if( 2 > 1 && 1 < 3){
//     alert('correct!')
// }

// if(2 > 1){
//     if(1 < 3 ){
//         alert('correct!') 
//     }
//     alert('correct 1!') 
// }



// if((x === y || a ===b ) && c === d ){
//     g = h
// }
// else{
//     e = f
// }


// if( c ===d ){
//     if(x === y){
//         g = h
//     }else if(a ===b){
//         g = h 
//     }
//     else{
//         e = f
//     }
// }
// else{
//     e = f
// }


var city1 = 'karachi';
var city2 = 'hyderabad';
var city3 = 'islamabad';
var city4 = 'peshawar';
var city5 = 'quetta';


var arrCity = ['karachi','hyderabad','islamabad','peshawar','quetta'];

arrCity[0];
arrCity[3];

// length  ===> start from 1 
// index  ===> start from 0

// total no index = arr.length - 1 ;


// var userData = ["umair",25,'karachi',true,[1,2,3,4,5],["peshawar",'islamabad']];

// alert(userData[4][1])

// alert(userData[5][1])
// document.write(userData[5][1]+"<br />"+userData[1])


///alert(userData[0]+userData[4][1]);


// var arr = [];


// arr[0] = "umair";
// arr[1] = "karachi";
// alert(arr)


var userData = ["umair",25,'karachi',true];

// userData.pop()
// userData.pop()

// userData.push("true")




// alert(userData);
// userData.push("true",2321,true)

// userData.shift()
// alert(userData);



userData.unshift("khan","asdkj")
alert(userData);

// splice

// slice