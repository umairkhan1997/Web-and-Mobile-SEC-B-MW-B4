var integer=123
console.log(integer)
var Name="umair khan"
console.log(Nam)
var array=[1,2,3,4,5,6,7,string]
console.log(array)
var boolean=true
console.log(boolean)
var decimal=1.23333
console.log(decimal)