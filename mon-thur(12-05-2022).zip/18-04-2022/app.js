// var div1= document.getElementById("div1")

// var ptag= div1.getElementsByTagName("p")
// for(var i=0;i<ptag.length;i++){
//     ptag[i].style.color="red"
// }


// console.log(document.childNodes[0] ,'document')

// var res = document.childNodes[1].childNodes

// for(var i = 0 ; i<res.length;i++ ){
//     if(res[i].nodeValue == '\n'){
        
//     }
// }


// console.log(document.childNodes[1].childNodes[2].childNodes[1].parentNode ,'document')
// console.log(document.childNodes[1].childNodes[2].childNodes[1].previousSibling ,'document')
console.log(document.children[0].lastChild.previousSibling)