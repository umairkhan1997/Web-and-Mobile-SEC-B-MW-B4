// var day="monday"
// console.log(day.replace(day.charAt(0),day.charAt(0).toUpperCase()))
// // slice ,indexof ,lastindexof ,charat,replace
// var days=["monday","tuesday","wednesday"];


// for(var i =0;i<days.length;i++){
//     console.log(days[i].replace(days[i].charAt(0),days[i].charAt(0).toUpperCase()))
// }



// var scoreAvg = -1.4678;

// console.log(Math.round(scoreAvg))


// var scoreAvg = 1.4678;

// console.log(Math.ceil(scoreAvg))

// var scoreAvg = 1.4678;
// console.log(Math.floor(scoreAvg));



//  var res = Math.random();

//  var minusZero = (res * 6) + 1
// var finalRes = Math.floor(minusZero)

//  console.log(finalRes)


// var res = "213123";
// console.log(typeof parseInt(res))


// var res = "asdsa";
// console.log( parseInt(res))

// console.log(parseInt("1.9999"))

// console.log(parseFloat("1.9999"))



// var res = "213123.968976";
// console.log(Number(res));


// var numberAsNumber = 1234;
// var numberAsString = numberAsNumber.toString();



// var number1 = 1234.234;
// var number2 = 1234.634;

// var res = number1 + number2
// console.log(res.toFixed(2))


// var num = 868.4444
// console.log(num.toFixed(2))


// var rightNow = new Date();

// console.log(rightNow.getDay())

var dayNames = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
 
var now = new Date();

 var theDay = now.getDay();

 var nameOfToday = dayNames[theDay];

//  console.log(nameOfToday,'nameOfToday');
console.log(now.getTime())


