    // `/*
    // console.log(" hello ")
    // console.log(" hello ")
    // console.log(" hello ")
    // console.log(" hello ")
    // console.log(" hello ")
    // console.log(" hello ")
    // console.log(" hello ")
    // console.log(" hello ")
    // console.log(" hello ")
    // console.log(" hello ")
    // console.log(" hello ")
    // console.log(" hello ")
    // */

    // var time = +prompt(" sd ");

    // switch (time) {
    //   case 1:
    //     alert("morning");
    //     break;
    //   case 2:
    //     alert("evening");
    //     break;
    //   case 3:
    //     alert("night");
    //     break;
    //   default:
    //     alert("wrong input");
    //     break;
    // }

    // for(var i=0; i < 4 ;i++){
    // console.log(i,"for ka loop")
    // }
    // var j =0
    // while(j<=3) {
    // console.log(j,"while ka loop")
    // j++;
    // }
    var flag = true 
    // while (flag ) {
    // }
    // console.log("false")
    // bbar baar chale
    // prompt chale uske saaath
    // 6 chale to while band

    // var i =0
    // while(i<=3){
    //  console.log(i,"while")
    //  i++;
    // }
    // var j=0;
    do{
        var i = +prompt("  asdas ")
      switch (i) {
        case 1:
            alert("case 1")
          break;
        case 2:
            alert("case 2")
          break;
        case 6:
            alert("case 3")
            flag=false;
            
          break;
        default:
            alert("case default")
          break;
      }
    }while(flag)
