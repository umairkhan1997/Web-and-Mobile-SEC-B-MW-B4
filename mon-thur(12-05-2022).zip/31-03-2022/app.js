function getname(){
    // var name=document.getElementById("name").value
    // alert(name)
    // document.getElementById("name").value= "samiullah khan baba"
    var num = document.getElementById("num").value
//     if(num == 1){
// document.getElementById("num").value= "ek number"
//     }
//     else if(num == 2){
//         document.getElementById("num").value= "do number"
//     }
//     else{
//         document.getElementById("num").value= "das number"
//     }
if(num=="1"){
document.getElementById("num2").value="1"
}
}
