// if(2 == 3 ){
//    alert('Correct') 
// }

// if(2 != 3 ){
//     alert('Correct') 
//  }
 

// var fullname = prompt('enter your full name');

// if(fullname == "Muneer" + " Ahmad"){
//     alert('correct')
// }
 

// var totalCost = +prompt('enter total cost');

// if (totalCost === 81.50 + 135) {

// alert("winner")
// }


// var x = 3,y=1,a=5,b=1;

// if( x+y == a - b){
//     alert('correct')
// }



// var x = 3,y=1,a=5,b=1;


// if( x > y){  ////is greater then 
//     alert('correct')
// }


// if( x < y){  ////is less then 
//     alert('correct')
// }


var x = 3,y=3,a=5,b=1;

// if( x >= y){  ////is greater then and equal
//     alert('correct')
// }


// if( x <= y){  ////is greater then and equal
//     alert('correct')
// }

// var yourTicketNumber = 487208;

// if (yourTicketNumber !== 487208) {
//      alert("Better luck next time.");
//      }
//      else{
//         alert('winner')
//      }


// var score = 0,userIq = 'bewakoof';

// var res = prompt("write Pakistan capital")

// if(res == "islamabad"){
//     score++,
//     userIq="Intelligent"
// }
// else{
//     score--,
//     userIq="double bewakoof"
// }

// alert(score+userIq);

// var res = prompt("enter pakistan famous city name")
// var res1 = prompt("enter pakistan famous city name")

// if(res == 'karachi' || res == 'islamabad' ){
// alert('nice choice')
// }

// if(res == 'karachi' || res == 'islamabad' || res == "peshawar"){
// alert('nice choice')
// }

// if(res == 'karachi' && res1 == 'islamabad' ){
// alert('nice choice')
// }

