// alert('Hello World');


var userName = "Hammad"; ///string

var num = 122332  /// Integer or Number

var boolean = true /// true or false 

var float = 2.97;

var und = undefined;

// alert(userName);


// 2 steps of creating variable;


var marks;

var numbers = 12321;

var user_Name$24234;

// alert(marks);


// CASE SENSITIVE 
// rose == Rose == roSe ==rOse

// rose == rose 


var number = '12321';

// alert(typeof number)


var num1  = 3;

var res = num1 + 5;
// var res = "num1" + 5;

var res1 = num1 - 5;

var res2 = num1 * 5;

var res3 = num1 / 5;

var res4 = num1 % 5;

// alert(res);

var num2 = 1;

num2 = 5;


num2++; ////post increment

num2--;  // post decrement


--num2; ///pre decrement;
++num2; // pre increment

// alert(num2);


// var num3 = 7;

// var num4 = num3++;

// alert(num4+" "+num3);


//  var num3 = 7;

// var num4 = num3--;

// alert(num4+" "+num3);


// var num3 = 7;

// var num4 = --num3;

// alert(num4+" "+num3);



// var num3 = 7;

// var num4 = ++num3;

// alert(num4+" "+num3);

// var num5 = ((1 + 3) * 1) // 4

// var resultOfComputation = ((2 * 4) * 4) + 2;  // 34;


// alert(num5 + " " + resultOfComputation);

// alert('bmj'+1)
// alert("BMJ"+"232132")

// alert(2+2+3+"BMJ"+232132)///7BMJ232132
// alert(2+"2"+3+"BMJ"+232132) ///223BMJ232132



// var userName = prompt("Enter your Name","hammad")

// alert(userName);

// prompt("Enter your Name","hammad")

// if(2 == 5){
//     alert('Correct')
// }


// var userName = prompt('enter your name');

// if(userName == "umair"){
//     alert('welcome')
// }